const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

let browser = null;
const logsDir = path.join(__dirname, '../logs');

// Cache for train data with TTL (5 minutes)
const dataCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

// Enhanced mock data with more trains
const MOCK_TRAINS = {
  '12728': { train_number: '12728', train_name: 'Godavari Express', current_station: 'Raichur Junction', delay_minutes: 5, status: 'Delayed' },
  '12955': { train_number: '12955', train_name: 'Somnath Express', current_station: 'Nagpur Junction', delay_minutes: 0, status: 'On Time' },
  '12702': { train_number: '12702', train_name: 'Kazipet-Warangal Express', current_station: 'Secunderabad', delay_minutes: 8, status: 'Delayed' },
  '17015': { train_number: '17015', train_name: 'Hyderabad-Vijayawada Passenger', current_station: 'Parli Vaijnath', delay_minutes: 5, status: 'Delayed' },
  '11039': { train_number: '11039', train_name: 'Coromandel Express', current_station: 'Visakhapatnam', delay_minutes: 12, status: 'Delayed' }
};

// Statistics
const stats = {
  totalRequests: 0,
  cacheHits: 0,
  mockDataUsed: 0,
  errors: 0,
  startTime: Date.now()
};

/**
 * Initialize browser
 */
async function initBrowser() {
  if (!browser) {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
    });
  }
  return browser;
}

/**
 * Get cached train data
 */
function getCachedData(trainNumber) {
  const cacheKey = trainNumber.toString().toUpperCase();
  const cached = dataCache.get(cacheKey);

  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    console.log(`[Cache] Hit for train ${trainNumber}`);
    stats.cacheHits++;
    return cached.data;
  }

  if (cached) dataCache.delete(cacheKey);
  return null;
}

/**
 * Store data in cache
 */
function setCachedData(trainNumber, data) {
  const cacheKey = trainNumber.toString().toUpperCase();
  dataCache.set(cacheKey, { data, timestamp: Date.now() });
}

/**
 * Main function to get train status
 */
async function getTrainStatus(trainNumber) {
  stats.totalRequests++;

  // Check cache
  const cachedData = getCachedData(trainNumber);
  if (cachedData) return cachedData;

  let page = null;
  try {
    const browserInstance = await initBrowser();
    page = await browserInstance.newPage();

    await page.setViewport({ width: 1280, height: 720 });
    page.setDefaultTimeout(20000);
    page.setDefaultNavigationTimeout(20000);
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

    console.log(`[NTES] Fetching train ${trainNumber}...`);

    // Navigate to NTES
    try {
      await page.goto('https://enquiry.indianrail.gov.in/mntes/', { waitUntil: 'domcontentloaded', timeout: 15000 });
    } catch (e) {
      console.log('[NTES] Navigation error, using fallback');
    }

    await new Promise(r => setTimeout(r, 1500));

    // Try to submit form
    let trainData = null;
    try {
      const inputSelectors = [
        'input[name*="train"]',
        '#train',
        'input[id*="search"]',
        'input[placeholder*="train"]'
      ];

      for (const selector of inputSelectors) {
        try {
          const elem = await page.$(selector);
          if (elem) {
            await elem.click({ delay: 100 });
            await page.type(selector, trainNumber.toString(), { delay: 30 });
            console.log(`[NTES] Found input: ${selector}`);

            // Try submit
            const buttons = await page.$$('button');
            for (const btn of buttons) {
              const text = await page.evaluate(el => el.textContent.toLowerCase(), btn);
              if (text.includes('search') || text.includes('submit')) {
                await btn.click();
                console.log('[NTES] Clicked submit');
                break;
              }
            }

            // Wait and extract
            await new Promise(r => setTimeout(r, 2500));
            const text = await page.evaluate(() => document.body.innerText);
            trainData = extractTrainInfo(text, trainNumber);

            if (trainData && trainData.trainName) break;
          }
        } catch (e) {}
      }
    } catch (e) {
      console.log('[NTES] Form submission error');
    }

    // Save HTML for debugging
    try {
      const html = await page.content();
      if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
      fs.writeFileSync(path.join(logsDir, `ntes_${trainNumber}.html`), html.substring(0, 50000));
    } catch (e) {}

    await page.close();
    page = null;

    // Return data or fall back to mock
    if (trainData && trainData.trainName) {
      const result = {
        train_number: trainNumber,
        train_name: trainData.trainName,
        current_station: trainData.currentStation || 'Unknown',
        delay_minutes: trainData.delayMinutes || 0,
        status: trainData.status || 'Running',
        last_update: new Date().toISOString(),
        success: true,
        source: 'ntes'
      };
      setCachedData(trainNumber, result);
      return result;
    }

    // Use mock data
    const mockData = generateMockData(trainNumber);
    stats.mockDataUsed++;
    setCachedData(trainNumber, mockData);
    return mockData;

  } catch (error) {
    console.error('[NTES] Error:', error.message);
    stats.errors++;

    if (page) {
      try { await page.close(); } catch (e) {}
    }

    const mockData = generateMockData(trainNumber);
    setCachedData(trainNumber, mockData);
    return mockData;
  }
}

/**
 * Extract train info from HTML/text
 */
function extractTrainInfo(content, trainNumber = null) {
  if (!content || content.length < 50) return null;

  const lines = content.split('\n').map(l => l.trim()).filter(l => l.length > 2);
  let info = { trainName: null, currentStation: null, delayMinutes: null, status: null };

  for (const line of lines) {
    const lower = line.toLowerCase();

    if (!info.trainName && (lower.includes('express') || lower.includes('rajdhani') || lower.includes('shatabdi'))) {
      if (line.length < 100) info.trainName = line;
    }

    if (!info.currentStation && (lower.includes('station') || lower.includes('junction'))) {
      if (line.length < 80) info.currentStation = line;
    }

    if (!info.delayMinutes) {
      const match = line.match(/(\d+)\s*(m|min|minute)/i);
      if (match) info.delayMinutes = parseInt(match[1]);
    }

    if (!info.status) {
      if (lower.includes('on time')) info.status = 'On Time';
      else if (lower.includes('delay')) info.status = 'Delayed';
      else if (lower.includes('running')) info.status = 'Running';
    }
  }

  return info.trainName ? info : null;
}

/**
 * Generate mock data
 */
function generateMockData(trainNumber) {
  const num = trainNumber.toString();
  const mockData = MOCK_TRAINS[num];
  const base = mockData || {
    train_number: num,
    train_name: `Train ${num}`,
    current_station: 'En Route',
    delay_minutes: Math.floor(Math.random() * 15),
    status: Math.random() > 0.7 ? 'Delayed' : 'On Time'
  };

  return {
    train_number: num,
    train_name: base.train_name,
    current_station: base.current_station,
    delay_minutes: base.delay_minutes,
    status: base.status,
    last_update: new Date().toISOString(),
    success: true,
    source: 'mock'
  };
}

/**
 * Close browser
 */
async function closeBrowser() {
  if (browser) {
    try {
      await browser.close();
      browser = null;
      console.log('[NTES] Browser closed');
    } catch (e) {
      console.error('[NTES] Close error:', e.message);
    }
  }
}

/**
 * Get service statistics
 */
function getStats() {
  const uptime = Date.now() - stats.startTime;
  const cacheHitRate = stats.totalRequests > 0 ? ((stats.cacheHits / stats.totalRequests) * 100).toFixed(2) : 0;

  return {
    ...stats,
    cacheHitRate: `${cacheHitRate}%`,
    uptime: `${(uptime / 1000 / 60).toFixed(2)} min`,
    cacheSize: dataCache.size
  };
}

/**
 * Clear all cache
 */
function clearCache() {
  dataCache.clear();
  console.log('[Cache] Cleared');
}

/**
 * Get cache info
 */
function getCacheInfo() {
  return {
    size: dataCache.size,
    entries: Array.from(dataCache.keys()),
    ttl: `${CACHE_TTL / 1000 / 60} min`
  };
}

module.exports = {
  getTrainStatus,
  closeBrowser,
  clearCache,
  getCacheInfo,
  getStats,
  initBrowser
};

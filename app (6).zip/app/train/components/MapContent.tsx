'use client';

import React, { useEffect, useState, useMemo, useRef } from 'react';
import { TrainAnalytics } from '@/types/analytics';
import * as turf from '@turf/turf';

// Lazy load Leaflet
let L: any = null;

if (typeof window !== 'undefined') {
  try {
    L = require('leaflet');
    require('leaflet/dist/leaflet.css');
  } catch (err) {
    console.warn('Leaflet not installed');
  }
}

/**
 * Advanced Train Map Component
 * Features:
 * - Dark theme (Carto Dark Matter)
 * - OpenRailwayMap tiles for railway network
 * - Train route polyline with route snapping
 * - Animated train marker (🚆)
 * - Movement trail/history
 * - Nearby trains display
 * - Congestion heatmap
 * - Auto-zoom to train
 *
 * CRITICAL FIX: Proper effect lifecycle management
 * - Do NOT include `map` in effect dependencies (circular dependency issue)
 * - Separate initialization from updates
 * - Use refs to track map state instead of state
 * - Use conservative setView() instead of fancy flyTo() during init
 */
interface MapContentProps {
  analytics: TrainAnalytics;
}

interface TrainSnapshot {
  lat: number;
  lng: number;
  timestamp: number;
}

export default function MapContent({ analytics }: MapContentProps) {
  // Refs to track state without triggering re-renders
  const mapRef = useRef<any>(null);
  const mapInstanceRef = useRef<any>(null);
  const trainMarkerRef = useRef<any>(null);
  const trailPathRef = useRef<any>(null);
  const initCompleteRef = useRef(false);
  const lastTrainNumberRef = useRef<string | null>(null);

  // State for UI
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [trailHistory, setTrailHistory] = useState<TrainSnapshot[]>([]);
  const [railwayRoutesData, setRailwayRoutesData] = useState<any[]>([]);
  const [routesLoading, setRoutesLoading] = useState(true);

  // Fetch REAL train route data from mapview API
  useEffect(() => {
    const fetchRoutes = async () => {
      try {
        setRoutesLoading(true);
        const trainNumber = analytics.trainNumber;
        const url = `/api/mapview?trainNumber=${trainNumber}`;
        const response = await fetch(url);
        const data = await response.json();

        if (data.success && data.data?.route) {
          const route = data.data.route;
          setRailwayRoutesData([{
            name: `${route.trainName} Route`,
            active: true,
            color: route.color || '#00E0FF',
            coordinates: route.coordinates,
          }]);
          console.log('[MapContent] Loaded REAL train route from mapview API');
        }
      } catch (err) {
        console.error('[MapContent] Error fetching mapview route:', err);
      } finally {
        setRoutesLoading(false);
      }
    };

    fetchRoutes();
  }, [analytics.trainNumber]);

  // Memoize derived data
  const railwayRoutes = useMemo(
    () => railwayRoutesData.length > 0 ? railwayRoutesData : [{
      name: `${analytics.trainName || 'Train'} Route`,
      active: true,
      color: '#00E0FF',
      coordinates: [[analytics.currentLocation?.longitude || 77.2, analytics.currentLocation?.latitude || 28.6]],
    }],
    [railwayRoutesData, analytics.trainName, analytics.currentLocation]
  );

  const nearbyTrainsData = useMemo(
    () => analytics.nearbyTrains?.trains || [],
    [analytics.nearbyTrains?.trains]
  );

  // CRITICAL: One-time initialization only
  // NO MAP in dependency array to avoid circular re-initialization
  useEffect(() => {
    // Guard clauses
    if (!L || !mapRef.current || initCompleteRef.current) return;

    const lat = analytics.currentLocation?.latitude;
    const lng = analytics.currentLocation?.longitude;

    if (!lat || !lng || isNaN(lat) || isNaN(lng)) {
      console.log('⏳ Waiting for valid coordinates...');
      return;
    }

    // Check container dimensions
    const { offsetHeight = 0, offsetWidth = 0 } = mapRef.current;
    if (offsetHeight < 100 || offsetWidth < 100) {
      console.log('⏳ Container dimensions insufficient, retrying...');
      let retryCount = 0;
      const retryInterval = setInterval(() => {
        const { offsetHeight: h = 0, offsetWidth: w = 0 } = mapRef.current || {};
        if (h >= 100 && w >= 100) {
          clearInterval(retryInterval);
          // Trigger effect again by setting loading
          setLoading(false);
        } else if (++retryCount > 10) {
          clearInterval(retryInterval);
          setError('Container dimensions could not be determined');
          setLoading(false);
        }
      }, 100);
      return () => clearInterval(retryInterval);
    }

    setLoading(true);
    let mapInstance: any = null;

    try {
      // Verify container is in DOM
      if (!document.body.contains(mapRef.current)) {
        throw new Error('Container not in DOM');
      }

      console.log(`✅ Initializing map at ${lat.toFixed(4)}, ${lng.toFixed(4)}`);

      // Create map instance
      mapInstance = L.map(mapRef.current, {
        center: [lat, lng],
        zoom: 7,
        minZoom: 4,
        maxZoom: 16,
        preferCanvas: true,
        zoomAnimation: true,
      });

      mapInstanceRef.current = mapInstance;

      // Add base layers
      L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        { attribution: '© Carto', subdomains: 'abcd', maxZoom: 20 }
      ).addTo(mapInstance);

      L.tileLayer(
        'https://{s}.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png',
        { maxZoom: 19, attribution: '© OpenStreetMap | © OpenRailwayMap', opacity: 0.8 }
      ).addTo(mapInstance);

      // Add routes
      railwayRoutes.forEach((route) => {
        const lineString = turf.lineString(route.coordinates);
        const color = route.active ? route.color : '#666666';

        L.polyline(route.coordinates, {
          color,
          weight: route.active ? 4 : 2,
          opacity: route.active ? 0.9 : 0.4,
          dashArray: route.active ? '' : '8, 4',
          lineCap: 'round',
        }).addTo(mapInstance);

        if (route.active) {
          (mapInstance as any).activeRoute = lineString;
        }
      });

      // Calculate snapped position
      let snappedPosition = [lat, lng];
      if ((mapInstance as any).activeRoute) {
        try {
          const trainPoint = turf.point([lng, lat]);
          const snapped = turf.nearestPointOnLine((mapInstance as any).activeRoute, trainPoint);
          snappedPosition = [snapped.geometry.coordinates[1], snapped.geometry.coordinates[0]];
        } catch (e) {
          // Use GPS position
        }
      }

      // Add train marker
      const trainIcon = L.divIcon({
        html: '🚆',
        iconSize: [40, 40],
        className: 'train-marker-animated',
      });

      const trainMarker = L.marker(snappedPosition, { icon: trainIcon, zIndexOffset: 1000 }).addTo(mapInstance);
      trainMarkerRef.current = trainMarker;

      const statusColor = analytics.movementState === 'running' ? '#4caf50' : '#ff9800';
      trainMarker.bindPopup(`
        <div style="min-width: 240px; font-family: sans-serif;">
          <h3 style="color: ${statusColor};">🚆 ${analytics.trainName}</h3>
          <p>Train #: ${analytics.trainNumber}</p>
          <p>Speed: ${analytics.speed} km/h</p>
          <p>Delay: ${analytics.delay} min</p>
        </div>
      `);

      // Add trail
      const trailPolyline = L.polyline([snappedPosition], {
        color: '#00FF88',
        weight: 2,
        opacity: 0.6,
        dashArray: '2, 3',
      }).addTo(mapInstance);

      trailPathRef.current = trailPolyline;
      setTrailHistory([{ lat: snappedPosition[0], lng: snappedPosition[1], timestamp: Date.now() }]);

      // Set initial view - NO animation during init
      mapInstance.setView(snappedPosition, 8);

      setError(null);
      setLoading(false);
      initCompleteRef.current = true;

      console.log('✅ Map initialization complete');
    } catch (err) {
      console.error('❌ Map init error:', err);
      setError(err instanceof Error ? err.message : 'Map initialization failed');
      setLoading(false);

      if (mapInstance) {
        try {
          mapInstance.remove();
        } catch (e) {
          // Cleanup error
        }
      }
    }

    // Cleanup on unmount
    return () => {
      if (mapInstance) {
        try {
          mapInstance.remove();
        } catch (e) {
          // Cleanup error
        }
      }
    };
  }, []); // Empty dependency - ONE TIME only

  // Update train position when analytics change
  useEffect(() => {
    if (!mapInstanceRef.current || !trainMarkerRef.current || !L) return;

    const lat = analytics.currentLocation?.latitude;
    const lng = analytics.currentLocation?.longitude;

    if (!lat || !lng || isNaN(lat) || isNaN(lng)) return;

    try {
      let snappedPosition = [lat, lng];

      if ((mapInstanceRef.current as any).activeRoute) {
        try {
          const trainPoint = turf.point([lng, lat]);
          const snapped = turf.nearestPointOnLine((mapInstanceRef.current as any).activeRoute, trainPoint);
          snappedPosition = [snapped.geometry.coordinates[1], snapped.geometry.coordinates[0]];
        } catch (e) {
          // Use GPS
        }
      }

      trainMarkerRef.current.setLatLng(snappedPosition);

      // Update trail
      setTrailHistory((prev) => {
        const last = prev[prev.length - 1];
        const dist = turf.distance(
          turf.point([last.lng, last.lat]),
          turf.point([snappedPosition[1], snappedPosition[0]]),
          { units: 'kilometers' }
        );

        if (dist > 0.1) {
          const newHistory = [...prev, { lat: snappedPosition[0], lng: snappedPosition[1], timestamp: Date.now() }].slice(-50);

          // Update the polyline visualization
          if (trailPathRef.current) {
            trailPathRef.current.setLatLngs(
              newHistory.map(p => ({ lat: p.lat, lng: p.lng }))
            );
          }

          return newHistory;
        }
        return prev;
      });
    } catch (err) {
      console.error('Map update error:', err);
    }
  }, [analytics.currentLocation]);

  if (error) {
    return (
      <div
        style={{
          width: '100%',
          height: '500px',
          background: 'linear-gradient(135deg, #1a3a52 0%, #2a5a7a 100%)',
          borderRadius: '8px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#ff6b6b',
          padding: '20px',
          boxSizing: 'border-box',
          textAlign: 'center',
        }}
      >
        <p style={{ fontSize: '1.1em', fontWeight: '600', marginBottom: '8px' }}>📍 Map Error</p>
        <p style={{ fontSize: '0.9em', opacity: 0.9, marginBottom: '12px' }}>{error}</p>
        <p style={{ fontSize: '0.85em', opacity: 0.7 }}>Install Leaflet: npm install leaflet @turf/turf</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div
        style={{
          width: '100%',
          height: '500px',
          background: 'linear-gradient(135deg, #1a3a52 0%, #2a5a7a 100%)',
          borderRadius: '8px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#20b2aa',
          padding: '20px',
          boxSizing: 'border-box',
          textAlign: 'center',
        }}
      >
        <div
          style={{
            width: '40px',
            height: '40px',
            border: '3px solid #20b2aa',
            borderTop: '3px solid transparent',
            borderRadius: '50%',
            animation: 'spin 0.8s linear infinite',
            marginBottom: '12px',
          }}
        />
        <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
        <p style={{ fontSize: '1em', fontWeight: '600' }}>Loading map...</p>
        <p style={{ fontSize: '0.85em', opacity: 0.8, marginTop: '8px' }}>📍 Fetching location data</p>
      </div>
    );
  }

  return (
    <div
      ref={mapRef}
      style={{
        width: '100%',
        height: '500px',
        borderRadius: '8px',
        overflow: 'hidden',
        boxShadow: '0 4px 16px rgba(0, 0, 0, 0.2)',
        background: '#1a1a1a',
      }}
      className="mapContainer"
    />
  );
}

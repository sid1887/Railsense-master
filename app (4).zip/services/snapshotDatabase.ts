/**
 * Train Snapshot & Historical Database Layer
 * Captures and stores periodic snapshots of train position/state
 * Enables delay trend analysis, movement pattern detection, etc.
 *
 * Schema: train_snapshots
 * - id, trainNumber, stationCode, timestamp, delay, speed, status, etc.
 */

import sqlite3 from 'sqlite3';
import path from 'path';

export interface TrainSnapshot {
  id?: number;
  trainNumber: string;
  stationCode: string;
  stationName: string;
  latitude: number;
  longitude: number;
  speed: number; // km/h
  delay: number; // minutes
  status: 'running' | 'halted' | 'stopped';
  timestamp: string; // ISO timestamp
  createdAt?: string;
}

class SnapshotDatabase {
  private db: sqlite3.Database | null = null;
  private initialized = false;

  /**
   * Initialize database connection and create tables
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;

    return new Promise((resolve, reject) => {
      const dbPath = path.join(process.cwd(), 'railsense.db');

      this.db = new sqlite3.Database(dbPath, (err) => {
        if (err) {
          console.error('[SnapshotDB] Connection error:', err);
          reject(err);
          return;
        }

        console.log('[SnapshotDB] Connected to SQLite database');

        // Create tables if not exist
        this.createTables()
          .then(() => {
            this.initialized = true;
            resolve();
          })
          .catch(reject);
      });
    });
  }

  /**
   * Create necessary database schema
   */
  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      // Train snapshots table
      this.db!.run(
        `
        CREATE TABLE IF NOT EXISTS train_snapshots (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          trainNumber TEXT NOT NULL,
          stationCode TEXT,
          stationName TEXT,
          latitude REAL,
          longitude REAL,
          speed REAL DEFAULT 0,
          delay REAL DEFAULT 0,
          status TEXT DEFAULT 'running',
          timestamp TEXT NOT NULL,
          createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
          INDEX (trainNumber, timestamp),
          INDEX (stationCode),
          INDEX (createdAt)
        )
      `,
        (err) => {
          if (err && !err.message.includes('already exists')) {
            reject(err);
            return;
          }

          // Delay statistics table (aggregated by hour)
          this.db!.run(
            `
            CREATE TABLE IF NOT EXISTS delay_statistics (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              stationCode TEXT NOT NULL,
              hour INTEGER,
              avgDelay REAL,
              maxDelay REAL,
              minDelay REAL,
              trainCount INTEGER,
              date TEXT NOT NULL,
              INDEX (stationCode, date, hour)
            )
          `,
            (err) => {
              if (err && !err.message.includes('already exists')) {
                reject(err);
                return;
              }

              console.log('[SnapshotDB] Tables created/verified');
              resolve();
            }
          );
        }
      );
    });
  }

  /**
   * Insert or update train snapshot
   */
  async saveSnapshot(snapshot: TrainSnapshot): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      this.db!.run(
        `
        INSERT INTO train_snapshots
        (trainNumber, stationCode, stationName, latitude, longitude, speed, delay, status, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          snapshot.trainNumber,
          snapshot.stationCode,
          snapshot.stationName,
          snapshot.latitude,
          snapshot.longitude,
          snapshot.speed,
          snapshot.delay,
          snapshot.status,
          snapshot.timestamp,
        ],
        function (err) {
          if (err) {
            reject(err);
            return;
          }
          resolve(this.lastID);
        }
      );
    });
  }

  /**
   * Get snapshots for a train over time range
   */
  async getTrainHistory(
    trainNumber: string,
    hours: number = 24
  ): Promise<TrainSnapshot[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();

      this.db!.all(
        `
        SELECT * FROM train_snapshots
        WHERE trainNumber = ? AND timestamp >= ?
        ORDER BY timestamp DESC
        LIMIT 1000
      `,
        [trainNumber, cutoffTime],
        (err, rows) => {
          if (err) {
            reject(err);
            return;
          }
          resolve((rows as any[]) || []);
        }
      );
    });
  }

  /**
   * Get delay statistics for a station
   */
  async getStationDelayStats(
    stationCode: string,
    days: number = 7
  ): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      this.db!.all(
        `
        SELECT
          hour,
          ROUND(AVG(avgDelay), 2) as avgDelay,
          MAX(maxDelay) as maxDelay,
          SUM(trainCount) as trainCount
        FROM delay_statistics
        WHERE stationCode = ? AND date >= date('now', '-${days} days')
        GROUP BY hour
        ORDER BY hour
      `,
        [stationCode],
        (err, rows) => {
          if (err) {
            reject(err);
            return;
          }
          resolve((rows as any[]) || []);
        }
      );
    });
  }

  /**
   * Calculate aggregated delay statistics
   */
  async calculateHourlyStats(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const today = new Date().toISOString().split('T')[0];

      // Aggregate snapshots into hourly statistics
      this.db!.run(
        `
        INSERT OR REPLACE INTO delay_statistics
        (stationCode, hour, avgDelay, maxDelay, minDelay, trainCount, date)
        SELECT
          stationCode,
          CAST(strftime('%H', timestamp) AS INTEGER) as hour,
          ROUND(AVG(delay), 2),
          MAX(delay),
          MIN(delay),
          COUNT(DISTINCT trainNumber),
          ?
        FROM train_snapshots
        WHERE DATE(timestamp) = ?
        GROUP BY stationCode, hour
      `,
        [today, today],
        (err) => {
          if (err) {
            reject(err);
            return;
          }
          resolve();
        }
      );
    });
  }

  /**
   * Get network-wide delay heatmap
   */
  async getNetworkHeatmap(hours: number = 1): Promise<Record<string, number>> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();

      this.db!.all(
        `
        SELECT stationCode, ROUND(AVG(delay), 1) as avgDelay
        FROM train_snapshots
        WHERE timestamp >= ?
        GROUP BY stationCode
      `,
        [cutoffTime],
        (err, rows: any[]) => {
          if (err) {
            reject(err);
            return;
          }

          const heatmap: Record<string, number> = {};
          (rows || []).forEach(row => {
            heatmap[row.stationCode] = row.avgDelay || 0;
          });

          resolve(heatmap);
        }
      );
    });
  }

  /**
   * Cleanup old snapshots (retention policy: 30 days)
   */
  async cleanupOldSnapshots(retentionDays: number = 30): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const cutoffDate = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000).toISOString();

      this.db!.run(
        `
        DELETE FROM train_snapshots
        WHERE timestamp < ?
      `,
        [cutoffDate],
        function (err) {
          if (err) {
            reject(err);
            return;
          }
          resolve(this.changes);
        }
      );
    });
  }

  /**
   * Close database connection
   */
  async close(): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      this.db!.close((err) => {
        if (err) {
          reject(err);
          return;
        }
        console.log('[SnapshotDB] Connection closed');
        resolve();
      });
    });
  }
}

const snapshotDatabase = new SnapshotDatabase();
export default snapshotDatabase;

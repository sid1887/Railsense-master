/**
 * Map Track Snapping Service
 * Snaps train coordinates to actual railway tracks
 * Improves map accuracy by ensuring trains appear on track polygons
 */

export interface TrackSegment {
  id: string;
  name: string;
  startStation: { code: string; name: string };
  endStation: { code: string; name: string };
  coordinates: Array<{ latitude: number; longitude: number }>;
  section: string;
}

export interface SnappedPosition {
  original: { latitude: number; longitude: number };
  snapped: { latitude: number; longitude: number };
  distance: number; // km from original to snapped position
  trackSegment: TrackSegment;
}

class MapTrackSnapping {
  // Mock track database - in production uses OpenRailwayMap data
  private tracks: Map<string, TrackSegment> = new Map([
    ['TRK_001', {
      id: 'TRK_001',
      name: 'Mumbai-Nagpur Main Line',
      startStation: { code: 'MMCT', name: 'Mumbai Central' },
      endStation: { code: 'NG', name: 'Nagpur Junction' },
      coordinates: [
        { latitude: 18.9676, longitude: 72.8194 }, // Mumbai
        { latitude: 19.1136, longitude: 72.9123 },
        { latitude: 19.8000, longitude: 75.8000 },
        { latitude: 21.1458, longitude: 79.0882 }, // Nagpur
      ],
      section: 'Central Railway',
    }],
    ['TRK_002', {
      id: 'TRK_002',
      name: 'Delhi-Bangalore Main Line',
      startStation: { code: 'NDLS', name: 'New Delhi' },
      endStation: { code: 'SBC', name: 'Bangalore City' },
      coordinates: [
        { latitude: 28.5431, longitude: 77.2506 }, // Delhi
        { latitude: 26.8465, longitude: 75.7465 }, // Jaipur area
        { latitude: 23.1815, longitude: 79.9864 }, // Jabalpur area
        { latitude: 12.9716, longitude: 77.5946 }, // Bangalore
      ],
      section: 'South Central Railway',
    }],
    ['TRK_003', {
      id: 'TRK_003',
      name: 'Secunderabad-Bengaluru Main Line',
      startStation: { code: 'SC', name: 'Secunderabad' },
      endStation: { code: 'SBC', name: 'Bangalore City' },
      coordinates: [
        { latitude: 17.3667, longitude: 78.467 }, // Secunderabad
        { latitude: 16.5000, longitude: 78.5000 },
        { latitude: 14.3000, longitude: 77.7000 },
        { latitude: 12.9716, longitude: 77.5946 }, // Bangalore
      ],
      section: 'South Central Railway',
    }],
    ['TRK_004', {
      id: 'TRK_004',
      name: 'Howrah-Guwahati Line',
      startStation: { code: 'HWH', name: 'Howrah' },
      endStation: { code: 'GHY', name: 'Guwahati' },
      coordinates: [
        { latitude: 22.5726, longitude: 88.3639 }, // Howrah
        { latitude: 23.1800, longitude: 87.8000 },
        { latitude: 25.5000, longitude: 90.0000 },
        { latitude: 26.1445, longitude: 91.7362 }, // Guwahati
      ],
      section: 'North East Frontier Railway',
    }],
  ]);

  /**
   * Snap train position to nearest track
   */
  snapToNearestTrack(latitude: number, longitude: number): SnappedPosition | null {
    let closestTrack: TrackSegment | null = null;
    let closestDistance = Infinity;
    let closestPoint = { latitude, longitude };

    // Find nearest track
    for (const track of this.tracks.values()) {
      for (let i = 0; i < track.coordinates.length - 1; i++) {
        const segmentStart = track.coordinates[i];
        const segmentEnd = track.coordinates[i + 1];

        const snappedPoint = this.projectPointOntoSegment(
          latitude,
          longitude,
          segmentStart.latitude,
          segmentStart.longitude,
          segmentEnd.latitude,
          segmentEnd.longitude
        );

        const distance = this.calculateDistance(
          latitude,
          longitude,
          snappedPoint.latitude,
          snappedPoint.longitude
        );

        if (distance < closestDistance) {
          closestDistance = distance;
          closestTrack = track;
          closestPoint = snappedPoint;
        }
      }
    }

    if (!closestTrack) return null;

    // Only snap if within 2km of track
    if (closestDistance > 2) return null;

    return {
      original: { latitude, longitude },
      snapped: closestPoint,
      distance: closestDistance,
      trackSegment: closestTrack,
    };
  }

  /**
   * Project point onto line segment
   */
  private projectPointOntoSegment(
    px: number,
    py: number,
    x1: number,
    y1: number,
    x2: number,
    y2: number
  ): { latitude: number; longitude: number } {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lengthSq = dx * dx + dy * dy;

    if (lengthSq === 0) return { latitude: x1, longitude: y1 };

    let t = ((px - x1) * dx + (py - y1) * dy) / lengthSq;
    t = Math.max(0, Math.min(1, t));

    const projX = x1 + t * dx;
    const projY = y1 + t * dy;

    return { latitude: projX, longitude: projY };
  }

  /**
   * Calculate distance between two points
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Get all track segments for map display
   */
  getAllTracks(): TrackSegment[] {
    return Array.from(this.tracks.values());
  }

  /**
   * Get tracks for a route
   */
  getTracksForRoute(stationCodeStart: string, stationCodeEnd: string): TrackSegment[] {
    return Array.from(this.tracks.values()).filter(
      track =>
        (track.startStation.code === stationCodeStart &&
          track.endStation.code === stationCodeEnd) ||
        (track.startStation.code === stationCodeEnd &&
          track.endStation.code === stationCodeStart)
    );
  }

  /**
   * Get track by segment ID
   */
  getTrackById(trackId: string): TrackSegment | null {
    return this.tracks.get(trackId) || null;
  }

  /**
   * Add new track (for updates)
   */
  addTrack(track: TrackSegment): void {
    this.tracks.set(track.id, track);
  }
}

const mapTrackSnapping = new MapTrackSnapping();
export default mapTrackSnapping;

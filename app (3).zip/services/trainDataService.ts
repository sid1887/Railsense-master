/**
 * Train Data Service
 * Handles fetching train data from APIs or mock data
 * Provides fallback mechanism for demo mode
 */

import axios from 'axios';
import { TrainData } from '@/types/train';
import mockData from '@/public/mockTrainData.json';
import { getLiveTrainPosition } from './railYatriService';
import { verifyTrainOnTrack } from './railwayMapService';
import { logger } from './logger';
import { getTrainStatus } from './ntesService';

// Load REAL train data provider (based on actual Indian Railways schedules)
let realTrainProvider: any = null;
if (typeof window === 'undefined') {
  try {
    realTrainProvider = require('./realTrainDataProvider');
  } catch (e) {
    console.warn('[TrainDataService] Real train provider not available:', e);
  }
}

// Load realistic data provider for demo (server-side only)
let realisticProvider: any = null;
if (typeof window === 'undefined') {
  try {
    realisticProvider = require('./realisticDataProvider');
  } catch (e) {
    // Provider not available
  }
}

// Simple in-memory cache with 30s TTL
const dataCache = new Map<string, { data: TrainData | null; timestamp: number }>();
const CACHE_TTL = 30 * 1000; // 30 seconds

function getCachedData(trainNumber: string): TrainData | null | undefined {
  const key = trainNumber.toUpperCase();
  const cached = dataCache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    console.log(`[Cache] Hit for train ${trainNumber}`);
    return cached.data;
  }
  return undefined;
}

function setCachedData(trainNumber: string, data: TrainData | null) {
  const key = trainNumber.toUpperCase();
  dataCache.set(key, { data, timestamp: Date.now() });
}

/**
 * Simulates real train movement by slightly modifying mock data
 * Increments location and updates delay for realistic demo
 */
function simulateTrainMovement(train: TrainData): TrainData {
  // Simulate slight movement on map
  const latVariation = (Math.random() - 0.5) * 0.01;
  const lonVariation = (Math.random() - 0.5) * 0.01;

  // Simulate speed changes
  let speedVariation = Math.random() * 10 - 5;
  let newSpeed = Math.max(0, train.speed + speedVariation);
  if (newSpeed > 0 && Math.random() > 0.8) newSpeed = 0; // Random stop

  // Simulate delay changes
  const delayVariation = Math.random() * 3 - 1.5;
  const newDelay = Math.max(0, train.delay + delayVariation);

  return {
    ...train,
    currentLocation: {
      ...train.currentLocation,
      latitude: train.currentLocation.latitude + latVariation,
      longitude: train.currentLocation.longitude + lonVariation,
      timestamp: Date.now(),
    },
    speed: parseFloat(newSpeed.toFixed(2)),
    delay: parseFloat(newDelay.toFixed(2)),
  };
}

/**
 * Fetch train data from mock JSON
 * Used as fallback when API is unavailable
 */
async function fetchMockTrainData(trainNumber: string): Promise<TrainData | null> {
  try {
    const mockTrain = (mockData as any).trains.find(
      (train: TrainData) =>
        train.trainNumber.toLowerCase() === trainNumber.toLowerCase() ||
        train.trainName.toLowerCase().includes(trainNumber.toLowerCase())
    );

    if (!mockTrain) return null;

    // Simulate live movement
    return simulateTrainMovement(mockTrain);
  } catch (err) {
    console.error('Error fetching mock data:', err);
    return null;
  }
}

/**
 * Fetch train data from external API
 * Returns null if API fails (fallback to mock)
 */
async function fetchFromAPI(trainNumber: string): Promise<TrainData | null> {
  try {
    // Skip API calls in demo/development - use mock data instead
    if (typeof window === 'undefined') {
      // Server-side: skip external API calls
      return null;
    }

    const apiUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3000/api';
    const response = await axios.get(`${apiUrl}/train?trainNumber=${trainNumber}`, {
      timeout: 5000,
    });
    return response.data;
  } catch (err) {
    console.warn('API fetch failed, falling back to mock data:', err);
    return null;
  }
}

/**
 * Fetch live train data from NTES (National Train Enquiry System)
 * Official Indian Railways data source
 */
async function fetchFromNTES(trainNumber: string): Promise<TrainData | null> {
  try {
    if (typeof window !== 'undefined') {
      // Only run on server side
      return null;
    }

    console.log(`[NTES] Fetching status for train ${trainNumber}...`);

    const ntesData = await getTrainStatus(trainNumber);

    if (!ntesData || !ntesData.success) {
      console.log(`[NTES] No data returned for train ${trainNumber}`);
      return null;
    }

    // Get base mock train for schedule/stations
    const mockTrain = (mockData as any).trains.find(
      (train: TrainData) =>
        train.trainNumber.toLowerCase() === trainNumber.toLowerCase() ||
        train.trainName.toLowerCase().includes(trainNumber.toLowerCase())
    );

    if (!mockTrain) {
      console.log(`[NTES] Train ${trainNumber} not found in mock data for merging`);
      return null;
    }

    // Merge NTES status with mock schedule data
    const trainData: TrainData = {
      ...mockTrain,
      trainName: ntesData.train_name || mockTrain.trainName,
      delay: ntesData.delay_minutes || 0,
      status: mapNTESStatus(ntesData.status),
      // Keep mock location for demo, would be updated from real source
      lastUpdated: new Date(ntesData.last_update).getTime(),
    };

    console.log(`[NTES] Successfully merged data for train ${trainNumber}`);
    return trainData;
  } catch (err) {
    console.warn(`[NTES] Failed to fetch data for ${trainNumber}:`, err);
    return null;
  }
}

/**
 * Map NTES status to local status format
 */
function mapNTESStatus(ntesStatus: string | undefined): string {
  if (!ntesStatus) return 'Running';
  const status = ntesStatus.toLowerCase();
  if (status.includes('delayed')) return 'Delayed';
  if (status.includes('on time')) return 'On Time';
  if (status.includes('running')) return 'Running';
  return 'Running';
}

/**
 * Fetch realistic simulated data based on actual train routes
 * Used when live APIs unavailable - provides realistic movement along Indian Railway routes
 */
async function fetchFromRealisticProvider(trainNumber: string): Promise<TrainData | null> {
  try {
    if (typeof window !== 'undefined' || !realisticProvider) {
      // Only on server-side and if provider available
      return null;
    }

    console.log(`[DataService] Attempting realistic provider for ${trainNumber}...`);
    const realisticData = realisticProvider.getCurrentPosition(trainNumber);

    if (!realisticData) {
      return null;
    }

    // Get base mock train for schedule/stations
    const mockTrain = (mockData as any).trains.find(
      (train: TrainData) =>
        train.trainNumber.toLowerCase() === trainNumber.toLowerCase() ||
        train.trainName.toLowerCase().includes(trainNumber.toLowerCase())
    );

    if (!mockTrain) {
      return null;
    }

    // Merge realistic position with mock schedule
    const trainData: TrainData = {
      ...mockTrain,
      currentLocation: {
        latitude: realisticData.lat,
        longitude: realisticData.lng,
        timestamp: Date.now(),
      },
      speed: realisticData.speed,
      delay: realisticData.delay_minutes,
      status: realisticData.status,
      source: 'realistic-simulation'
    };

    console.log(`[DataService] ✓ Using realistic data for train ${trainNumber}: lat=${realisticData.lat.toFixed(2)}, lng=${realisticData.lng.toFixed(2)}, progress=${realisticData.progress_percent}%`);
    return trainData;
  } catch (err) {
    console.warn(`[DataService] Realistic provider failed for ${trainNumber}:`, err);
    return null;
  }
}

/**
 * Fetch REAL train data based on actual Indian Railways schedules
 * Uses real train numbers, stations, distances, and departure times from IR database
 */
async function fetchFromRealProvider(trainNumber: string): Promise<TrainData | null> {
  try {
    if (typeof window !== 'undefined' || !realTrainProvider) {
      // Only on server-side and if provider available
      return null;
    }

    console.log(`[RealDataProvider] Fetching REAL data for train ${trainNumber}...`);

    if (!realTrainProvider.isRealTrain(trainNumber)) {
      console.log(`[RealDataProvider] Train ${trainNumber} not in real database`);
      return null;
    }

    const realData = realTrainProvider.getCurrentPosition(trainNumber);
    if (!realData) {
      return null;
    }

    // Get train info from real database
    const trainInfo = realTrainProvider.getTrainInfo(trainNumber);
    if (!trainInfo) {
      return null;
    }

    // Get base mock train for any missing fields
    const mockTrain = (mockData as any).trains.find(
      (train: TrainData) =>
        train.trainNumber.toLowerCase() === trainNumber.toLowerCase() ||
        train.trainName.toLowerCase().includes(trainNumber.toLowerCase())
    );

    // Build real train data
    const trainData: TrainData = {
      ...(mockTrain || {}),
      trainNumber: trainInfo.trainNumber,
      trainName: trainInfo.trainName,
      currentLocation: {
        latitude: realData.lat,
        longitude: realData.lng,
        timestamp: Date.now(),
      },
      speed: realData.speed,
      delay: realData.delay_minutes,
      status: realData.status,
      source: 'real-schedule',
      lastUpdated: Date.now(),
    };

    console.log(`[RealDataProvider] ✓ Using REAL data for train ${trainNumber} (${trainInfo.trainName}): at ${realData.currentStation}, progress=${realData.progress_percent}%, speed=${realData.speed}km/h, delay=${realData.delay_minutes}min`);
    return trainData;
  } catch (err) {
    console.warn(`[RealDataProvider] Failed to fetch real data for ${trainNumber}:`, err);
    return null;
  }
}

/**
 * Fetch live train data from RailYatri
 * Converts RailYatri format to our TrainData format
 */
async function fetchFromRailYatri(trainNumber: string): Promise<TrainData | null> {
  try {
    const liveData = await getLiveTrainPosition(trainNumber);
    if (!liveData) return null;

    // Get base mock train for schedule/stations
    const mockTrain = (mockData as any).trains.find(
      (train: TrainData) =>
        train.trainNumber.toLowerCase() === trainNumber.toLowerCase() ||
        train.trainName.toLowerCase().includes(trainNumber.toLowerCase())
    );

    if (!mockTrain) return null;

    // Verify train is on actual track using OpenRailwayMap
    const onTrack = await verifyTrainOnTrack(liveData.lat, liveData.lng);
    if (!onTrack) {
      console.warn(`[RailYatri] Train ${trainNumber} off-track (data anomaly)`);
      return null;
    }

    // Merge live position with mock schedule data
    const trainData: TrainData = {
      ...mockTrain,
      currentLocation: {
        latitude: liveData.lat,
        longitude: liveData.lng,
        timestamp: liveData.timestamp * 1000, // Convert to ms
      },
      speed: liveData.speed || 0,
      delay: liveData.delay || 0,
    };

    console.log(`[RailYatri] Using live data for train ${trainNumber}`);
    return trainData;
  } catch (err) {
    console.warn(`[RailYatri] Failed to fetch live data for ${trainNumber}`);
    return null;
  }
}

/**
 * Main function to get train data
 * Priority: NTES → RailYatri → API → **REAL Train Schedule** → Realistic Sim → Mock (fallback)
 *           (Official)   (Live)   (Custom)  (Real Indian IR data)  (Algorithm)   (Static)
 */
export async function getTrainData(trainNumber: string): Promise<TrainData | null> {
  // Normalize input
  const normalized = trainNumber.toUpperCase().trim();

  if (!normalized) {
    throw new Error('Train number is required');
  }

  // Check cache first
  const cached = getCachedData(normalized);
  if (cached !== undefined) {
    return cached;
  }

  try {
    // 1. Try NTES first (official government source - most reliable)
    console.log(`[DataService] Attempting NTES fetch for ${normalized}...`);
    const ntesData = await fetchFromNTES(normalized);
    if (ntesData) {
      console.log(`[DataService] ✓ Using NTES data for train ${normalized}`);
      setCachedData(normalized, ntesData);
      return ntesData;
    }

    // 2. Try RailYatri for live position data
    console.log(`[DataService] NTES failed, attempting RailYatri for ${normalized}...`);
    const railYatriData = await fetchFromRailYatri(normalized);
    if (railYatriData) {
      console.log(`[DataService] ✓ Using RailYatri live data for train ${normalized}`);
      setCachedData(normalized, railYatriData);
      return railYatriData;
    }

    // 3. Try custom API
    if (process.env.NEXT_PUBLIC_DEMO_MODE !== 'true') {
      console.log(`[DataService] RailYatri failed, attempting API for ${normalized}...`);
      const apiData = await fetchFromAPI(normalized);
      if (apiData) {
        console.log(`[DataService] ✓ Using API data for train ${normalized}`);
        setCachedData(normalized, apiData);
        return apiData;
      }
    }

    // 4. Try REAL train data provider (based on actual IR schedules and distances)
    console.log(`[DataService] API failed, attempting REAL train schedule data for ${normalized}...`);
    const realData = await fetchFromRealProvider(normalized);
    if (realData) {
      console.log(`[DataService] ✓ Using REAL train schedule data for ${normalized}`);
      setCachedData(normalized, realData);
      return realData;
    }

    // 5. Try realistic data provider (simulated but realistic coordinates/movement)
    console.log(`[DataService] Real provider failed, attempting realistic simulation for ${normalized}...`);
    const realisticData = await fetchFromRealisticProvider(normalized);
    if (realisticData) {
      console.log(`[DataService] ✓ Using realistic simulation for train ${normalized}`);
      setCachedData(normalized, realisticData);
      return realisticData;
    }

    // 6. Fall back to static mock data (last resort)
    console.warn(`[DataService] All live sources failed for ${normalized}, using MOCK data`);
    const mockDataResult = await fetchMockTrainData(normalized);
    if (mockDataResult) {
      mockDataResult.source = 'mock'; // Tag as mock data
      console.warn(`[Demo Mode] ⚠ Using static mock data for train ${normalized}`);
      setCachedData(normalized, mockDataResult);
      return mockDataResult;
    }

    // Not found anywhere
    console.error(`[DataService] Train ${normalized} not found in any data source`);
    setCachedData(normalized, null);
    return null;
  } catch (err) {
    console.error('Error in getTrainData:', err);
    setCachedData(normalized, null);
    throw err;
  }
}

/**
 * Get multiple trains data (for traffic analysis)
 * Useful for finding nearby trains
 */
export async function getNearbyTrainsData(): Promise<TrainData[]> {
  try {
    return (mockData as any).trains.map((train: TrainData) => simulateTrainMovement(train));
  } catch (err) {
    console.error('Error fetching nearby trains:', err);
    return [];
  }
}

/**
 * Get mock configuration data
 * Contains thresholds and factors for analysis
 */
export async function getMockConfig() {
  try {
    return {
      congestionFactors: (mockData as any).congestionFactors,
      defaultWeather: (mockData as any).defaultWeather,
    };
  } catch (err) {
    console.error('Error fetching config:', err);
    return {
      congestionFactors: {
        lowTrafficWait: 5,
        mediumTrafficWait: 12,
        highTrafficWait: 20,
        weatherFactor: 2,
      },
      defaultWeather: {
        temperature: 28,
        condition: 'Partly Cloudy',
        visibility: 10,
        windSpeed: 15,
        precipitation: false,
        code: '02d',
      },
    };
  }
}

/**
 * Search trains by name or number
 * Returns array of matching trains
 */
export async function searchTrains(query: string): Promise<TrainData[]> {
  try {
    const normalized = query.toLowerCase();

    return (mockData as any).trains.filter(
      (train: TrainData) =>
        train.trainNumber.toLowerCase().includes(normalized) ||
        train.trainName.toLowerCase().includes(normalized) ||
        train.source.toLowerCase().includes(normalized) ||
        train.destination.toLowerCase().includes(normalized)
    );
  } catch (err) {
    console.error('Error searching trains:', err);
    return [];
  }
}
